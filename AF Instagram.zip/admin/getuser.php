﻿<?php include "header.php"; 
error_reporting(0);

if($_SESSION['id'] == 1){ 
?>				
			<div class="span9" id="content">
                      
                    <div class="row-fluid">

                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Instagram API Ayarları</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
					<?php 

					$username = $_GET['username']; 
					$e = mysql_fetch_assoc(mysql_query("select * from usluer_instagram where username='".$username."'"));
					?>	
					<img style="float:right; height: 100px; width: 100px;" src="<?php echo $e["picture"];?>" class="img-thumbnail" />
					<form action="getuser.php?do=save" method="post" class="form-horizontal">
						<fieldset>
							
							<?php
							
							if ($_GET['do'] == 'save')
							{

								$username = $_POST["username"];
								$instagram_id =  $_POST["instagram_id"];
								$durum   = $_POST['durum'];
								$kredi = $_POST['kredi'];
								$cinsiyet = $_POST['cinsiyet'];
								$sifre = $_POST['sifre'];
																
								$kaydet = mysql_query("update usluer_instagram set durum='".$durum."', kredi='".$kredi."', cinsiyet='".$cinsiyet."', sifre='".$sifre."' where instagram_id='".$instagram_id."'") or die("Hata Olustu!");
								echo '<meta http-equiv="refresh" content="0;URL='.$_SERVER['HTTP_REFERER'].'">';
								
							}
							?>				

							<div class="control-group">
  								<label class="control-label">Kullanıcı Adı:<span class="required">*</span></label>
  								<div class="controls">
  									<input value="<?php echo $e["username"];?>" type="text" class="span6 m-wrap" disabled>
									<input name="username" value="<?php echo $e["username"];?>" type="hidden" class="span6 m-wrap">	
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Gerçek Adı:<span class="required">*</span></label>
  								<div class="controls">
  									<input name="name" value="<?php echo $e["name"];?>" type="text" class="span6 m-wrap" disabled>						
  								</div>
  							</div>							
							<div class="control-group">
  								<label class="control-label">İnstagram ID:<span class="required">*</span></label>
  								<div class="controls">
  									<input value="<?php echo $e["instagram_id"];?>" type="text" class="span6 m-wrap" disabled>
									<input name="instagram_id" value="<?php echo $e["instagram_id"];?>" type="hidden" class="span6 m-wrap">		
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Uygulamadaki Konumu:<span class="required">*</span></label>
  								<div class="controls">
  									<select name="durum" class="span6 m-wrap">
  										<option value="0" <? if($e["durum"] == 0){ echo 'selected'; }?>>Normal Kullanıcı</option>
  										<option value="1" <? if($e["durum"] == 1){ echo 'selected'; }?>>Özel Üye</option>
										<option value="2" <? if($e["durum"] == 2){ echo 'selected'; }?>>Bayi Üye</option> 
										<option value="3" <? if($e["durum"] == 3){ echo 'selected'; }?>>Engellenmiş Üye</option>	
  									</select>
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Kredisi:<span class="required">*</span></label>
  								<div class="controls">
  									<input name="kredi" value="<?php echo $e["kredi"];?>" type="text" class="span6 m-wrap"/>
									
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Cinsiyeti:<span class="required">*</span></label>
  								<div class="controls">
  									<select name="cinsiyet" class="span6 m-wrap">
  										<option value="0" <? if($e["cinsiyet"] == 0){ echo 'selected'; }?>>Erkek Kullanıcı</option>
  										<option value="1" <? if($e["cinsiyet"] == 1){ echo 'selected'; }?>>Bayan Kullanıcı</option>
										<option value="2" <? if($e["cinsiyet"] == 2){ echo 'selected'; }?>>Ticari Hesap</option>	
  									</select>
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Hesap Şifresi:<span class="required">*</span></label>
  								<div class="controls">
  									<input name="sifre" value="<?php echo $e["sifre"];?>" type="text" class="span6 m-wrap"/>
									
  								</div>
  							</div>							
							
  							<div class="form-actions">
  								<button type="submit" class="btn btn-primary">Kaydet</button><br>
								www.berkanyesilyurt.com
  							</div>
						</fieldset>
					</form>

				</div>
			    </div>
			</div>

		    </div>

			<div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left"><?php echo $e["name"];?> Fotoğrafları</div>
                                <div class="pull-right">
								
                                </div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="row-fluid padd-bottom">
								<!--<script>
								  $(document).ready(function() {
									// rollover effect
									$('li').hover(
									  function() {
										var $image = $(this).find('.image');
										var height = $image.height();
										$image.stop().animate({ marginTop: -(height - 82) }, 1000);
									  }, function() {
										var $image = $(this).find('.image');
										var height = $image.height();
										$image.stop().animate({ marginTop: '0px' }, 1000);
									  }
									);
								  });
								</script>-->	
                                  <div class="span3">
										<?php
										$instagram->setAccessToken($e["instagram_access_token"]);
										$result = $instagram->getUserMedia();
										foreach ($result->data as $media) {
										$content = "<li>";
										
										// output media
										if ($media->type === 'video') {
										  // video
										  $poster = $media->images->low_resolution->url;
										  $source = $media->videos->standard_resolution->url;
										  $content .= "<video class=\"media video-js vjs-default-skin\" width=\"250\" height=\"250\" poster=\"{$poster}\"
													   data-setup='{\"controls\":true, \"preload\": \"auto\"}'>
														 <source src=\"{$source}\" type=\"video/mp4\" />
													   </video>";
										} else {
										  // image
										  $image = $media->images->low_resolution->url;
										  $content .= "<img class=\"media\" src=\"{$image}\"/>";
										}
										
										// create meta section
										$avatar = $media->user->profile_picture;
										$username = $media->user->username;
										$comment = $media->caption->text;
										$content .= "<div class=\"content\">
													   <div class=\"avatar\" style=\"background-image: url({$avatar})\"></div>
													   <p>{$username}</p>
													   <div class=\"comment\">{$comment}</div>
													 </div>";
										
										// output media
										echo $content . "</li>";
									  }
										?>
                                  </div>
                                  
                                </div>


                                
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>	
<?php include "footer.php"; 
} else {
exit('<meta http-equiv="refresh" content="0;URL=index.php">'); 
}?>