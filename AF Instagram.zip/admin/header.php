<?PHP
@session_start();
if($_SESSION['login'] !== true){
	exit('<meta http-equiv="refresh" content="0;URL=login.php">'); 
}
include '../assets/inc/config.php';

?>
<!DOCTYPE html>
<html class="no-js">
    
    <head>
		<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
        <title>[ Admin Panel ]</title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="vendors/easypiechart/jquery.easy-pie-chart.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    
    <body>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="index.php">Admin Panel</a>
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
							<?php
							if($_SESSION['id'] == 1){ 
							?>
                            <li>	
							<form class="navbar-form navbar-left" action="getuser.php" method="get" role="search">
							
							<input type="text" name="username" placeholder="Pengguna Instagram" class="form-control" />
							<button type="submit" class="btn btn-default">Cari</button>
							</form>
							</li>
							<?php } ?>
							<li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-user"></i> <?php echo $_SESSION['isim']; ?> <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="profile.php">Ubah Info Saya</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="logout.php">Keluar</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul class="nav">
                            <li class="active">
                                <a href="index.php">Halaman</a>
                            </li>
							<?php
							if($_SESSION['id'] == 1){ 
							?>
                            <li class="dropdown">
                                <a href="#" data-toggle="dropdown" class="dropdown-toggle">Pengaturan <b class="caret"></b>

                                </a>
                                <ul class="dropdown-menu" id="menu1">
                                    <li>
                                        <a href="seo-settings.php">Pengaturan Search Engine</a>
                                    </li>
                                    <li>
                                        <a href="instagram-api.php">Pengaturan Api Instagram</a>
                                    </li> 
                                </ul>
                            </li>
							<?php } ?>
							<?php
							if($_SESSION['id'] == 1){ 
							?>
                           
							<?php } ?>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span3" id="sidebar">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
                        <li class="active">
                            <a href="index.php"><i class="icon-chevron-right"></i> Halaman</a>
                        </li>
                        <li>
                            <a href="follow.php"><i class="icon-chevron-right"></i>Tambahkan Followers</a>
                        </li>
                        <li>
                            <a href="like.php"><i class="icon-chevron-right"></i>Tambahkan Likers</a>
                        </li>
						<?php
							if($_SESSION['id'] == 1){ 
						?>
						<li>
							<?php $kacKisi = mysql_num_rows(mysql_query("SELECT * FROM usluer_instagram where durum='0' ")); ?>
                            <a href="users.php"><span class="badge badge-success pull-right"><?php echo $kacKisi; ?></span>Daftar pengguna aktif</a>
                        </li>
						
                        <li>
							<?php $gelenkutusu = mysql_num_rows(mysql_query("SELECT * FROM usluer_iletisim")); ?>
                            <a href="inbox.php"><span class="badge badge-important pull-right"><?php echo $gelenkutusu; ?></span> Inbox</a>
                        </li>
                        <?php } ?>                        
                    </ul>
                </div>
				
			