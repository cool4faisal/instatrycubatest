﻿<?php include "header.php"; 
if($_SESSION['id'] == 1){ 
?>
<?php 
			function ip(){
			if(getenv("HTTP_CLIENT_IP")) {
				$ip = getenv("HTTP_CLIENT_IP");
			} elseif(getenv("HTTP_X_FORWARDED_FOR")) {
				$ip = getenv("HTTP_X_FORWARDED_FOR");
				if (strstr($ip, ',')) {
					$tmp = explode (',', $ip);
					$ip = trim($tmp[0]);
				}
			} else {
			$ip = getenv("REMOTE_ADDR");
			}
			return $ip;
			}

?>			
								<div class="span9" id="content">
                                        
								<div class="row-fluid">
								<div class="span12">
								<!-- block -->
								<div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">Inbox</div>
									<?php $gelenkutusu = mysql_num_rows(mysql_query("SELECT * FROM usluer_iletisim")); ?>
                                    <div class="pull-right"><span class="badge badge-info">Inbox: <?php echo $gelenkutusu; ?></span>

                                    </div>
                                </div>
                                <div class="block-content collapse in">

                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>E-Mail</th>
                                                <th>Tema</th>
                                                <th>Pesan</th>
												<th>IP Adress</th>
												<th>Sejarah</th>
												<th>Sil</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										<?PHP
										$iletisim = mysql_query("select * from usluer_iletisim order by id") or die("Hata Olustu!");									 
										while($goster=mysql_fetch_assoc($iletisim))
										{
										?>
                                            <tr>
                                                <td><?PHP echo $goster['id']; ?></td>
                                                <td><?PHP echo $goster['email']; ?></td>
                                                <td><?PHP
												if($goster['konu'] == 1){
												 echo "Ödeme Bildirimi";
												}else if($goster['konu'] == 2){
												 echo "Öneri / Hata Bildirimi";												
												}
												 
												?></td>
                                                <td><?PHP echo $goster['mesaj']; ?></td>
												<td><?PHP echo $goster['ip_adresi']; ?></td>
												<td><?PHP echo $goster['tarih']; ?></td>
												<?php
												/*if ($_GET['do'] == 'delete')
												{
												$id = $_POST['id'];
												$delete = mysql_query("delete from usluer_iletisim where id=$id");
												if ($delete) {
													echo '<meta http-equiv="refresh" content="0;URL=inbox.php">';
												}
												}*/
												?>
												<?php
												if(isset($_GET['delete'])){
									
												mysql_query("DELETE FROM usluer_iletisim WHERE id = ".intval($_GET['delete'])."");
												echo '<meta http-equiv="refresh" content="0;URL=./inbox.php">';
										
												}
												
												?>
												<td><a href="inbox.php?delete=<?PHP echo $goster['id']; ?>">Sil</a></td>
                                            </tr>
                                        <?PHP } ?>    
                                        </tbody>
                                    </table>

                                </div>
								</div>
								<!-- /block -->
								</div>
								</div>
								</div>	
			
				
<?php include "footer.php"; 
} else {
exit('<meta http-equiv="refresh" content="0;URL=index.php">'); 
}?>