﻿<?php include "header.php"; ?>
				
			<div class="span9" id="content">
                      
                    <div class="row-fluid">

                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">
								<?php if($_SESSION['id'] == 1){ ?>
								Genel Site Yönetimi
								<?php } else {?>
								Hoşgeldin; <?php echo $_SESSION['isim']; ?>
								<?php }?>
								</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
					<?php if($_SESSION['id'] == 1){ ?>
					<form action="index.php?do=save" method="post" class="form-horizontal">
						<fieldset>
						
						
						
							
						
							<?php $e = mysql_fetch_assoc(mysql_query("select * from usluer_genel_ayarlar where id='1'"));?>
							<?php
							
							if ($_GET['do'] == 'save')
							{
								$uyekredi = $_POST['uyekredi'];
								$ozeluyekredi   = $_POST['ozeluyekredi'];
								$paypalmailadresi = $_POST['paypalmailadresi'];
								$ozeluyelikucreti = $_POST['ozeluyelikucreti'];
								$giristetakip = $_POST['giristetakip'];
								$kullanici_id = $_POST['kullanici_id'];
								$giristebegeni = $_POST['giristebegeni'];
								$media_id = $_POST['media_id'];
								
								$kaydet = mysql_query("update usluer_genel_ayarlar set uyekredi='$uyekredi', ozeluyekredi='$ozeluyekredi', paypalmailadresi='$paypalmailadresi', ozeluyelikucreti='$ozeluyelikucreti', giristetakip='$giristetakip', kullanici_id='$kullanici_id', giristebegeni='$giristebegeni', media_id='$media_id' where id='1'") or die("Hata Olustu!");
								if($kaydet)
								{
									echo '
									<div class="alert alert-success">
										<button class="close" data-dismiss="alert">&times;</button>
										Düzenleme işlemi başarıyla gerçekleşmiştir.
									</div>
									';
									echo '<meta http-equiv="refresh" content="1;URL=index.php">
';
								}
							}
							?>
							
							
							
							
							
  							<div class="control-group">
  								<label class="control-label">Credit Member Biasa:<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" name="uyekredi" data-required="1" value="<?php echo $e["uyekredi"];?>" class="span6 m-wrap"/>
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Credit Member VIP:<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" name="ozeluyekredi" data-required="1" value="<?php echo $e["ozeluyekredi"];?>" class="span6 m-wrap"/>
									<span class="help-block">Masukan Limit Credit untuk setiap pengguna. Kredit yang tersisa tidak dapat bertambah di hari berikutnya !</span>
  								</div>
  							</div>
							
							<hr/>
							
  							<div class="control-group">
  								<label class="control-label">Email Paypal :<span class="required">*</span></label>
  								<div class="controls">
  									<input name="paypalmailadresi" type="text" value="<?php echo $e["paypalmailadresi"];?>" class="span6 m-wrap"/>
									
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Biaya Khusus Member:<span class="required">*</span></label>
  								<div class="controls">
  									<input name="ozeluyelikucreti" value="<?php echo $e["ozeluyelikucreti"];?>" type="text" class="span6 m-wrap"/>
									
  								</div>
  							</div>
							
  							<hr/>

  							
  							<div class="control-group">
  								<label class="control-label">Auto Follow admin<span class="required">*</span></label>
  								<div class="controls">
  									<select name="giristetakip" class="span6 m-wrap">
  										<option value="0" <? if($e["giristetakip"] == 0){ echo 'selected'; }?>>Matikan</option>
  										<option value="1" <? if($e["giristetakip"] == 1){ echo 'selected'; }?>>Aktifkan</option> 										
  									</select>
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Instagram/User ID:<span class="required">*</span></label>
  								<div class="controls">
  									<input name="kullanici_id" type="text" value="<?php echo $e["kullanici_id"];?>" class="span6 m-wrap"/>
									<span class="help-block">Masukan User ID yang akan di ikuti !</span>
  								</div>
  							</div>
							
							<hr/>
							
							<div class="control-group">
  								<label class="control-label">Auto Like Foto<span class="required">*</span></label>
  								<div class="controls">
  									<select class="span6 m-wrap" name="giristebegeni">
  										<option value="0" <? if($e["giristebegeni"] == 0){ echo 'selected'; }?>>Matikan</option>
  										<option value="1" <? if($e["giristebegeni"] == 1){ echo 'selected'; }?>>Aktifkan</option> 										
  									</select>
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Media ID:<span class="required">*</span></label>
  								<div class="controls">
  									<input name="media_id" value="<?php echo $e["media_id"];?>" type="text" class="span6 m-wrap"/>
									<span class="help-block">Pengguna Akan Otomatis menyukai Foto Anda !</span>
  								</div>
  							</div>
  							<div class="form-actions">
  								<button type="submit" class="btn btn-primary">Kaydet</button>
  							</div>
						</fieldset>
					</form>
					<?php } else {?>
					<div class="alert alert-success alert-dismissable">
					<?php $bilgi = mysql_fetch_assoc(mysql_query("select * from usluer_yonetim where id='".$_SESSION['id']."'"));?>
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					Halo, <b><?php echo $bilgi['isim']; ?></b>.  <b><?php echo $bilgi['kredi']; ?></b> Anda menggunakan kredit yang tersedia . <br/>
					Anda <b><?php echo $bilgi['odenenmiktar']; ?></b> Harus membayar yang di setujui !
					</div>
							<?php if($bilgi['duyuru_durum'] == 1){ ?>
							<div class="alert alert-dismissable alert-info">
							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
							<h4>Pesan Masuk !</h4> 
							<?php echo $bilgi['duyuru']; ?>
							</div>
							<?php }?>
					<?php }?>
				</div>
			    </div>
			</div>

		    </div>



                </div>	
<?php include "footer.php"; ?>