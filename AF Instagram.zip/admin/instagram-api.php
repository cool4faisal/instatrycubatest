﻿<?php include "header.php"; 
if($_SESSION['id'] == 1){ 
?>				
				
			<div class="span9" id="content">
                      
                    <div class="row-fluid">

                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Instagram API Ayarları</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">

					<form action="instagram-api.php?do=save" method="post" class="form-horizontal">
						<fieldset>
						
						
						
							
						
							<?php $e = mysql_fetch_assoc(mysql_query("select * from usluer_client where id='1'"));?>
							<?php
							
							if ($_GET['do'] == 'save')
							{
								$client_id = $_POST['client_id'];
								$client_secret   = $_POST['client_secret'];
								$client_website = $_POST['client_website'];
								$client_callback = $_POST['client_callback'];
																
								$kaydet = mysql_query("update usluer_client set client_id='$client_id', client_secret='$client_secret', client_website='$client_website', client_callback='$client_callback' where id='1'") or die("Hata Olustu!");
								if($kaydet)
								{
									echo '
									<div class="alert alert-success">
										<button class="close" data-dismiss="alert">&times;</button>
										Düzenleme işlemi başarıyla gerçekleşmiştir.
									</div>
									';
									echo '<meta http-equiv="refresh" content="1;URL=instagram-api.php">
';
								}
							}
							?>
							
							
							
							
							
  							<div class="control-group">
  								<label class="control-label">Client ID:<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" name="client_id" data-required="1" value="<?php echo $e["client_id"];?>" class="span6 m-wrap"/>
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Client Secret:<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" name="client_secret" data-required="1" value="<?php echo $e["client_secret"];?>" class="span6 m-wrap"/>						
  								</div>
  							</div>
							
							<hr/>
							
  							<div class="control-group">
  								<label class="control-label">Client Website:<span class="required">*</span></label>
  								<div class="controls">
  									<input name="client_website" type="text" value="<?php echo $e["client_website"];?>" class="span6 m-wrap"/>
									
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Client Callback:<span class="required">*</span></label>
  								<div class="controls">
  									<input name="client_callback" value="<?php echo $e["client_callback"];?>" type="text" class="span6 m-wrap"/>
									
  								</div>
  							</div>
							

  							<div class="form-actions">
  								<button type="submit" class="btn btn-primary">Kaydet</button>
  							</div>
						</fieldset>
					</form>

				</div>
			    </div>
			</div>

		    </div>



                </div>	
<?php include "footer.php"; 
} else {
exit('<meta http-equiv="refresh" content="0;URL=index.php">'); 
}?>