﻿<?php include "header.php"; ?>
		
								<div class="span9" id="content">
                                        
								<div class="row-fluid">
								<div class="span12">
								<!-- block -->
								<div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">Penambah Likes Foto Instagram</div>
									<?php $kacKisi = mysql_num_rows(mysql_query("SELECT * FROM usluer_instagram WHERE durum='0'")); ?>
                                    <div class="pull-right"><span class="badge badge-info">Total Member yang bisa di tambahkan: <?php echo $kacKisi;?></span>

                                    </div>
                                </div>
                                <div class="block-content collapse in">
								<?php $e = mysql_fetch_assoc(mysql_query("select * from usluer_yonetim where id='".$_SESSION['id']."'"));?>
								<?php if ($e["kredi"] > 0){ ?>																	
								<div class="alert alert-dismissable alert-warning">
								 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>																	
								Harap dicatat bahwa jumlah transaksi yang berhasil sampai kredit, ada <b><?php echo $e["kredi"];?></b> Ini akan dipotong dari kredit Anda . <br/>
								Untuk Mendapatkan Media Id Buka Instagram.com/usernamekamu > Pilih Foto yang akan di tambah > Copy linknya dan masukan di bagian  http://api.instagram.com/oembed?url=PASTE_DISINI_LINK_POTO_MU	
								</div>
								<?php } else if ($e["kredi"] <= 0){?>
								<div class="alert alert-dismissable alert-danger">								
								Anda tidak memiliki karena Anda tidak bisa lagi memproses pinjaman .
								</div>
								<?php } ?>
								
								<?php if ($e["kredi"] > 0){ ?>	
                                <form action="like.php" method="post" class="form-horizontal">
								<fieldset>

									<div class="control-group">
										<label class="control-label">Media ID:<span class="required">*</span></label>
										<div class="controls">
											<input type="text" placeholder=" http://api.instagram.com/oembed?url=https://instagram.com/p/4WUDOFqUd-/?taken-by=farhangraph" name="media_id" data-required="1" class="span6 m-wrap"/>											
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Jumlah Likes<span class="required">*</span></label>
										<div class="controls">
											<input type="text" name="kisi_sayisi" data-required="1" class="span6 m-wrap"/>											
										</div>
									</div>

									<div class="form-actions">
										<input class="btn btn-primary" type="submit" value="Submit">
							
									</div>
								</fieldset>
								</form>
								<?php } ?>
								<?php
								if ($_POST)
								{
								$media_id = $_POST['media_id'];
								$kisi_sayisi = $_POST['kisi_sayisi'];
								$id = $_SESSION['id'];
								
								$bilgi = mysql_fetch_assoc(mysql_query("SELECT * FROM usluer_yonetim WHERE id='".$id."'"));
								$limit = $bilgi['kredi'];
								$query = mysql_query("SELECT * FROM usluer_instagram WHERE durum='0' ORDER BY rand() limit ".$kisi_sayisi."");
								$i = 0;
								$error = 0;
								$success = 0;
								while ($value = mysql_fetch_array($query))
										{
									$instagram_access_token[$i] = $value["instagram_access_token"];
									$i++;
										}
								
								if ($limit > 0)
									{
								for ($i = 0;$i < mysql_num_rows($query);$i++)
								{
									try
									{
										$instagram->setAccessToken($instagram_access_token[$i]);
										$instagram->likeMedia($media_id);
										$success = $success + 1;
										mysql_query("UPDATE usluer_yonetim SET kredi=kredi-1 WHERE id='".$id."'");
										$limit--;
										if ($limit <= 0)
										{
											break;
										}	
				
									}
									catch (Exception $e)
									{
									}
								}
									}

								echo '<div class="alert alert-success alert-dismissable">
								<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
								<b>Operasi Sukses ! Menyegarkan kredit Anda .</b>
								</div>';
								echo '<meta http-equiv="refresh" content="3;URL=./follow.php">';
								}
								?>
								
								
                                </div>
								
								
								</div>
								<!-- /block -->
								</div>
								</div>
								</div>	
			
				
<?php include "footer.php"; ?>