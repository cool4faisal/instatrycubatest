<?php
include '../assets/inc/config.php';
@session_start();



if ($_GET['do'] == 'login')
{
$email   = $_POST['email'];
$sifre   = $_POST['sifre'];

	if(($email == "") or ($sifre == "")){ 
    echo '<script type="text/javascript">alert("Lütfen boş alan bırakmayın!");</script>';
    echo '<meta http-equiv="refresh" content="0;URL=login.php">';
	}else{
	
	$uyeler = mysql_query("SELECT * FROM usluer_yonetim WHERE email='$email' and sifre='$sifre'");
	$uyebul = mysql_num_rows($uyeler);
		if($uyebul > 0){
			$uye_bilgileri = mysql_query("SELECT * FROM usluer_yonetim WHERE email='$email'");
			$uye_bilgileri_getir = mysql_fetch_array($uye_bilgileri);
			$_SESSION['id']   = $uye_bilgileri_getir['id'];
			$_SESSION['email']   = $uye_bilgileri_getir['email'];
			$_SESSION['sifre']   = $uye_bilgileri_getir['sifre'];
			$_SESSION['isim']   = $uye_bilgileri_getir['isim'];
			$_SESSION['kredi']   = $uye_bilgileri_getir['kredi'];
			$_SESSION['odenenmiktar']   = $uye_bilgileri_getir['odenenmiktar'];
			$_SESSION['durum']   = $uye_bilgileri_getir['durum'];
			$_SESSION['telefon']   = $uye_bilgileri_getir['telefon'];
			$_SESSION['duyuru_durum']   = $uye_bilgileri_getir['duyuru_durum'];
			$_SESSION['duyuru']   = $uye_bilgileri_getir['duyuru'];
			$_SESSION['login']	= true;
			echo '<meta http-equiv="refresh" content="0;URL=index.php">';
		}else{
			echo '<meta http-equiv="refresh" content="0;URL=login.php">';		
		}
	}
}
?>
<!DOCTYPE html>
<html>
  <head><meta http-equiv="Content-Type" content="text/html; charset=big5">
	
    <title>[ Admin ]</title>
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
    <link href="assets/styles.css" rel="stylesheet" media="screen">
     <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
  </head>
  <body id="login">
    <div class="container">

      <form class="form-signin" action="login.php?do=login" method="post">
        <h2 class="form-signin-heading">Login</h2>
        <input type="text" name="email" class="input-block-level" placeholder="admin">
        <input type="password" name="sifre"class="input-block-level" placeholder="Password">
        
        <button class="btn btn-large btn-primary" type="submit">Masuk</button>
		<p><br/></p>
		<div class="alert alert-error">
		<button class="close" data-dismiss="alert">&times;</button>
		<strong><a title="Download PHP Script" target="_blank" href="http://tutorials.fajaralrahmansyah.web.id/2016/03/membuat-website-auto-followers-instagram-plus-admin-panel.html">Instagram Admin Panel Script 2016</a></strong></div>
      </form>
		
    </div> <!-- /container -->
    <script src="vendors/jquery-1.9.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>