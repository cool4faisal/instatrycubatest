<?php
$admin = $_POST ["user"];
$passwd = $_POST ["password"];

if (($admin == "user") or($passwd == "member")){
	echo '<meta http-equiv="refresh" content="0;URL=index.php">';
}
else {
	echo "Password salah";
}
?>