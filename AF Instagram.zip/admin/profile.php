﻿<?php include "header.php"; ?>				
				
			<div class="span9" id="content">
                      
                    <div class="row-fluid">

                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left"><?php echo $_SESSION['isim'];?> Profile</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
					<?php
							if($_SESSION['id'] > 1){ 
					?>
					
					<form action="profile.php?do=save" method="post" class="form-horizontal">
						<fieldset>
						
						
						
							
						
							<?php $e = mysql_fetch_assoc(mysql_query("select * from usluer_yonetim where id='".$_SESSION['id']."'"));?>
							<?php
							
							if ($_GET['do'] == 'save')
							{
								$id = $_POST['id'];
								$sifre   = $_POST['sifre'];
								
																
								$kaydet = mysql_query("update usluer_yonetim set sifre='$sifre' where id='$id'") or die("Hata Olustu!");
								if($kaydet)
								{
									echo '
									<div class="alert alert-success">
										<button class="close" data-dismiss="alert">&times;</button>
										Düzenleme işlemi başarıyla gerçekleşmiştir.
									</div>
									';
									echo '<meta http-equiv="refresh" content="1;URL=profile.php">
';
								}
							}
							?>
							
							
							
							
							
  							<div class="control-group">
  								<label class="control-label">E-Mail:<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" value="<?php echo $e["email"];?>" class="span6 m-wrap" disabled>
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Kata sandi:<span class="required">*</span></label>
  								<div class="controls">
									<input type="hidden" name="id" value="<?php echo $e["id"];?>" class="span6 m-wrap">
  									<input type="text" name="sifre" value="<?php echo $e["sifre"];?>" class="span6 m-wrap">
									<br/>
									<span class="help-inline">Jika Anda ingin mengubah password Anda , masukkan password baru Anda di sini , klik tombol Save .</span>
  								</div>
  							</div>
							
  							<div class="control-group">
  								<label class="control-label">Pemilik:<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" value="<?php echo $e["isim"];?>" class="span6 m-wrap" disabled>
									
  								</div>
  							</div>							
							
							<hr/>
							
							<div class="control-group">
  								<label class="control-label">Credit:<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" value="<?php echo $e["kredi"];?>" class="span6 m-wrap" disabled>
									
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Jumlah Yang Pernah Di Bayar:<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" value="<?php echo $e["odenenmiktar"];?>" class="span6 m-wrap" disabled>
									
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Vendor Status:<span class="required">*</span></label>
  								<div class="controls">
  									<input name="durum" value="<? if($e["durum"] == 0){ 
									echo 'Ödeme Onaylandı'; 
									}else if ($e["durum"] == 1){
									echo 'Yetersiz Kredi!'; 									
									}else if ($e["durum"] == 2){
									echo 'Ödeme Yapılmadı'; 									
									}
									?>" type="text" class="span6 m-wrap" disabled>
  								</div>
							</div>
							
							<hr/>
							
							<div class="control-group">
  								<label class="control-label">Telphone:<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" value="<?php echo $e["telefon"];?>" class="span6 m-wrap" disabled>
									
  								</div>
  							</div>

  							<div class="form-actions">
  								<button type="submit" class="btn btn-primary">Save</button>
  							</div>
						</fieldset>
					</form>
					
					
					<?php } else {?>
					
					<form action="profile.php?do=save" method="post" class="form-horizontal">
						<fieldset>
						
						
						
							
						
							<?php $e = mysql_fetch_assoc(mysql_query("select * from usluer_yonetim where id='".$_SESSION['id']."'"));?>
							<?php
							
							if ($_GET['do'] == 'save')
							{
								$id = $_POST['id'];
								$email = $_POST['email'];
								$sifre   = $_POST['sifre'];
								$isim   = $_POST['isim'];
								$kredi = $_POST['kredi'];
								
								$kaydet = mysql_query("update usluer_yonetim set sifre='$sifre', isim='$isim', kredi='$kredi', email='$email' where id='$id'") or die("Hata Olustu!");
								if($kaydet)
								{
									echo '
									<div class="alert alert-success">
										<button class="close" data-dismiss="alert">&times;</button>
										Düzenleme işlemi başarıyla gerçekleşmiştir.
									</div>
									';
									echo '<meta http-equiv="refresh" content="1;URL=profile.php">
';
								}
							}
							?>
							
							
							
							
							
  							<div class="control-group">
  								<label class="control-label">E-Mail:<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" name="email" value="<?php echo $e["email"];?>" class="span6 m-wrap">
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Kata Sandi:<span class="required">*</span></label>
  								<div class="controls">
									<input type="hidden" name="id" value="<?php echo $e["id"];?>" class="span6 m-wrap">
  									<input type="text" name="sifre" value="<?php echo $e["sifre"];?>" class="span6 m-wrap">
									<br/>
									<span class="help-inline">Jika Anda ingin mengubah password Anda , masukkan password baru Anda di sini , klik tombol Save.</span>
  								</div>
  							</div>
							
  							<div class="control-group">
  								<label class="control-label">Pemilik Situs:<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" name="isim" value="<?php echo $e["isim"];?>" class="span6 m-wrap">
									
  								</div>
  							</div>							
							
							<hr/>
							
							<div class="control-group">
  								<label class="control-label">Credit:<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" name="kredi" value="<?php echo $e["kredi"];?>" class="span6 m-wrap">
									
  								</div>
  							</div>



  							<div class="form-actions">
  								<button type="submit" class="btn btn-primary">Save</button>
  							</div>
						</fieldset>
					</form>
					<?php }?>
				</div>
			    </div>
			</div>

		    </div>



                </div>	
<?php include "footer.php"; ?>