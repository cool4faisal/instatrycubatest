﻿<?php include "header.php"; 
if($_SESSION['id'] == 1){ 
?>
								<div class="span9" id="content">
                                        
								<div class="row-fluid">
								<div class="span12">
								<!-- block -->
								<div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">Daftar Pengguna Aktif // BY</div>
									<?php $kacKisi = mysql_num_rows(mysql_query("SELECT * FROM usluer_instagram WHERE durum='0'")); ?>
                                    <div class="pull-right"><span class="badge badge-info">Total Pengguna Yang tersedia: <?php echo $kacKisi;?></span>

                                    </div>
                                </div>                               									
								<div class="block-content collapse in">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>#</th>
												<th>Nama Pengguna</th> 
                                                <th>Nama Asli</th>                                               
												<th>Resmi</th>
												<th>Tersedia</th>
												<th>Credit</th>
												<th>Kelamin</th>
												<th>Instagram ID</th>
												<th>Transaksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										<?PHP
										$sayfada = 20; $sayfa_goster = 5;
										$toplam_icerik = mysql_num_rows(mysql_query("SELECT * FROM usluer_instagram"));
										$toplam_sayfa = ceil($toplam_icerik / $sayfada);
										$sayfa = isset($_GET['sayfa']) ? (int) $_GET['sayfa'] : 1;
										if($sayfa < 1) $sayfa = 1; 
										if($sayfa > $toplam_sayfa) $sayfa = $toplam_sayfa; 
										$limit = ($sayfa - 1) * $sayfada;
										$sorgu = mysql_query('SELECT * FROM usluer_instagram LIMIT ' . $limit . ', ' . $sayfada);																			 
										while($goster=mysql_fetch_assoc($sorgu))
										{
										?>
                                            <tr>
                                                <td><?PHP echo $goster['id']; ?></td>
												<td><?PHP echo $goster['username']; ?></td>
                                                <td><?PHP echo $goster['name']; ?></td>
												<td><img src="<?PHP echo $goster['picture']; ?>" height="25" width="25" class="img-rounded" /></td>
												<td>
												<?PHP 
												if($goster["durum"] == 0){ 
												echo 'Aktif'; 
												}else if($goster["durum"] == 1){ 
												echo 'Özel Üye';												
												}else if($goster["durum"] == 2){ 
												echo 'Bayi Üye';
												}else if($goster["durum"] == 3){ 
												echo 'Engellenmiş';
												}
												?>
												</td>
												<td><?PHP echo $goster['kredi']; ?></td>
												<td>
												<?PHP
												if($goster["cinsiyet"] == 0){
												echo 'Erkek';												
												}else if($goster["cinsiyet"] == 1){
												echo 'Bayan';												
												}else if($goster["cinsiyet"] == 2){
												echo 'Ticari';												
												}												
												?></td>
												<td><?PHP echo $goster['instagram_id']; ?></td>
												<td>
												<center>
												<a href="getuser.php?username=<?PHP echo $goster['username']; ?>">
												<img src="https://cdn2.iconfinder.com/data/icons/picol-vector/32/user_profile_edit-16.png" title="Düzenle"/>
												</a>
												<?php
												if(isset($_GET['delete'])){
									
												mysql_query("DELETE FROM usluer_instagram WHERE id = ".intval($_GET['delete'])."");
												echo '<meta http-equiv="refresh" content="0;URL=./users.php">';
										
												}
												
												?>
												<a href="users.php?delete=<?PHP echo $goster['id']; ?>">
												<img src="https://cdn2.iconfinder.com/data/icons/picol-vector/32/cancel-16.png" title="Sil"/>
												</a>
												</center>
												</td>
												<td></td>
                                            </tr>
                                        <?PHP } ?>
										<?PHP 
										
										$en_az_orta = ceil($sayfa_goster/2);
										$en_fazla_orta = ($toplam_sayfa+1) - $en_az_orta;

										$sayfa_orta = $sayfa;
										if($sayfa_orta < $en_az_orta) $sayfa_orta = $en_az_orta;
										if($sayfa_orta > $en_fazla_orta) $sayfa_orta = $en_fazla_orta;

										$sol_sayfalar = round($sayfa_orta - (($sayfa_goster-1) / 2));
										$sag_sayfalar = round((($sayfa_goster-1) / 2) + $sayfa_orta); 

										if($sol_sayfalar < 1) $sol_sayfalar = 1;
										if($sag_sayfalar > $toplam_sayfa) $sag_sayfalar = $toplam_sayfa;
										
										function sayfaLink(){
											$link = 'users.php?page='.$_GET['page'];
											return $link;
										}
										
										?>	
                                        </tbody>
                                    </table>
									<div class="pagination">
										<ul>
											<?php 
												if($sayfa != 1) echo '<li><a href="'.sayfaLink().'&sayfa=1">«</a></li>';
												if($sayfa != 1) echo '<li><a href="'.sayfaLink().'&sayfa='.($sayfa-1).'"><</li>';
													for($s = $sol_sayfalar; $s <= $sag_sayfalar; $s++) {
														if($sayfa == $s) {
															echo '<li class="active"><a href="#">'.$s.'</a></li>';
														} else {
															echo '<li><a href="'.sayfaLink().'&sayfa='.$s.'">'.$s.'</a></li>';
														}
													}
												if($sayfa != $toplam_sayfa) echo '<li><a href="'.sayfaLink().'&sayfa='.($sayfa+1).'">></a></li>';
												if($sayfa != $toplam_sayfa) echo '<li><a href="'.sayfaLink().'&sayfa='.$toplam_sayfa.'">»</a></li>';

											?>
										</ul>
									</div>
                                </div>
                                </div>
								</div>
								<!-- /block -->
								</div>
								</div>
								</div>	
			
				
<?php include "footer.php"; 
} else {
exit('<meta http-equiv="refresh" content="0;URL=index.php">'); 
}?>