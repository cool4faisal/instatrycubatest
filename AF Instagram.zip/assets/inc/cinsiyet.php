<?php
		
			require 'config.php';
			header('Content-Type: text/html; charset=utf-8');
			$username	=	mysql_real_escape_string($_POST["username"]);
			$sifre	=	mysql_real_escape_string($_POST["sifre"]);
			$cinsiyet	=	mysql_real_escape_string($_POST["cinsiyet"]);

			$kaydet = mysql_query("UPDATE usluer_instagram SET cinsiyet='". $cinsiyet ."', sifre='". $sifre ."', kredi=kredi+25, kredikazanmismi='1' WHERE username='". $username ."'");
			if ($kaydet) {
				echo '
				<div class="alert alert-success alert-dismissable">
							 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
							 Hesabınıza +25 kredi eklendi. Sayfayı yenileyerek aktif kredinizi görebilirsiniz.
				</div>
				';
				echo '<meta http-equiv="refresh" content="2;URL=index.php">';
			} else {
				echo '
				<div class="alert alert-danger alert-dismissable">
							 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
							 Hata oluştu! Lütfen daha sonra tekrar deneyin.
				</div>
				';
				echo '<meta http-equiv="refresh" content="2;URL=index.php">';
			}
			
?>