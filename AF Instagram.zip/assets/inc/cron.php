<?php

			
			# Berkan YEŞİLYURT #
			# berkanyesilyurt.com #
			
			require 'config.php';

            $ayarlar = mysql_fetch_assoc(mysql_query("SELECT * FROM usluer_genel_ayarlar WHERE id='1'"));
            $uyekredi = $ayarlar['uyekredi'];
			$ozeluyekredi = $ayarlar['ozeluyekredi'];
            mysql_query("UPDATE usluer_instagram SET kredi='".$uyekredi."' WHERE durum='0' ");
			mysql_query("UPDATE usluer_instagram SET kredi='".$ozeluyekredi."' WHERE durum='1' ");
                       
			
?>