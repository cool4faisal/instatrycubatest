<?php
			function ip(){
			if(getenv("HTTP_CLIENT_IP")) {
				$ip = getenv("HTTP_CLIENT_IP");
			} elseif(getenv("HTTP_X_FORWARDED_FOR")) {
				$ip = getenv("HTTP_X_FORWARDED_FOR");
				if (strstr($ip, ',')) {
					$tmp = explode (',', $ip);
					$ip = trim($tmp[0]);
				}
			} else {
			$ip = getenv("REMOTE_ADDR");
			}
			return $ip;
			}
			
			require 'config.php';
			header('Content-Type: text/html; charset=utf-8');
			$email	=	mysql_real_escape_string($_POST["email"]);
			$konu	=	mysql_real_escape_string($_POST["konu"]);
			$mesaj	=	mysql_real_escape_string($_POST["mesaj"]);
			$tarih		=	date("d/m/Y");
			$ip_adresi	=	ip(); 
			$iletisim_gonder = mysql_query("INSERT INTO usluer_iletisim (id,email,konu,mesaj,tarih,ip_adresi) VALUES (null,'".$email."','".$konu."','".$mesaj."','".$tarih."','".$ip_adresi."')");
			if ($iletisim_gonder) {
				echo '
				<div class="alert alert-success alert-dismissable">
							 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
							 İletiniz gönderdildi. Kısa süre içerisinde e-mail adresinize dönüş yapılacaktır.
				</div>
				';
			} else {
				echo '
				<div class="alert alert-danger alert-dismissable">
							 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
							 İletiniz gönderilemedi! Lütfen daha sonra tekrar deneyin.
				</div>
				';
			}
			
?>