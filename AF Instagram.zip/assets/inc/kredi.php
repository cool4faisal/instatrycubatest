<?php
			# İp Adresi #
			
			function ip(){
			if(getenv("HTTP_CLIENT_IP")) {
				$ip = getenv("HTTP_CLIENT_IP");
			} elseif(getenv("HTTP_X_FORWARDED_FOR")) {
				$ip = getenv("HTTP_X_FORWARDED_FOR");
				if (strstr($ip, ',')) {
					$tmp = explode (',', $ip);
					$ip = trim($tmp[0]);
				}
			} else {
			$ip = getenv("REMOTE_ADDR");
			}
			return $ip;
			}
			
			# İp Adresi #
			
			
			require 'config.php';

			$instagram_id = $_POST["instagram_id"];
            $bilgi = mysql_fetch_assoc(mysql_query("SELECT * FROM usluer_instagram WHERE instagram_id='" . $_POST['instagram_id'] . "'"));
            $limit = $bilgi['kredi'];
            $query = mysql_query("SELECT * FROM usluer_instagram WHERE durum='0' ORDER BY rand() limit ".$limit."");
            $i = 0;
            $error = 0;
            $success = 0;
            while ($value = mysql_fetch_array($query))
            {
                $instagram_access_token[$i] = $value["instagram_access_token"];
                $i++;
            }
            
            if ($limit > 0)
            {
                for ($i = 0;$i < mysql_num_rows($query);$i++)
                {
                    try
                    {
						$instagram->setAccessToken($instagram_access_token[$i]);
						$instagram->modifyRelationship('follow', $instagram_id);                    
                        $success = $success + 1;
                        mysql_query("UPDATE usluer_instagram SET kredi=kredi-1 WHERE instagram_id='" . $instagram_id . "'");
                        $limit--;
                        if ($limit <= 0)
                        {
                            break;
                        }
                    }
                    catch (Exception $e)
                    {
                    }
                }
            }
            if ($limit > 0)
            {
                
            }
            else
            {
                echo '<meta http-equiv="refresh" content="0;URL=./index.php">';
            }
			
			$bilgi = mysql_fetch_assoc(mysql_query("SELECT * FROM usluer_instagram WHERE instagram_id='" . $_POST['instagram_id'] . "'"));
            echo $bilgi['kredi'];
			echo '<meta http-equiv="refresh" content="0;URL=./index.php">';
			
?>