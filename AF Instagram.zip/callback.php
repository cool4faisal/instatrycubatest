<?php
ob_start();
session_start();


// Bu dosyada düzenlenmesi gereken bir kısım yoktur.
// İnstagram api ayarlarındaki redirect yolu bu dosya olmalıdır.
// Dosyadaki oynamalar uzun vadede büyük açıklara sebep olabilir.
// Bu açıklamaları için Berkan Yeşilyurt'a bir teşekkür edebilirsiniz.
// Belki giren olur www.berkanyesilyurt.com

?>
<?php
	require_once 'assets/inc/config.php';

	$code = $_GET['code'];

	if (true === isset($code)) {
	$data = $instagram->getOAuthToken($code);  
	if(empty($data->user->username))
	{
	?>
<script>window.location="index.php";</script>
<?
	}
	else
	{
		session_start();
		setcookie("t", "$code");
		$t=$_COOKIE['t'];
		$_SESSION['user']=$data;
		$user=$data->user->username;
		$fullname=$data->user->full_name;
		$bio=$data->user->bio;
		$website=$data->user->website;
		$picture=$data->user->profile_picture;
		$id=$data->user->id;
		$token=$data->access_token;

	$kontrol = mysql_num_rows(mysql_query("SELECT * FROM usluer_instagram WHERE instagram_id='$id'")); 

	if ($kontrol == 1)  
	{
	
	mysql_query("update usluer_instagram set username='$user', name='$fullname', bio='$bio', website='$website', picture='$picture', instagram_access_token='$token' where instagram_id='$id'");
	
	}

	if ($kontrol == 0){	
	mysql_query("insert into usluer_instagram(username,name,bio,website,picture,durum,kredi,cinsiyet,sifre,instagram_id,instagram_access_token,kredikazanmismi) 
	values('$user','$fullname','$bio','$website','$picture','0','50','0','0','$id','$token','0')");	
	}
	
	
?>
<script>window.location="index.php";</script>
<?
	}
	} 
	else 
	{
	if (true === isset($_GET['error'])) 
	{
		echo 'An error occurred: '.$_GET['error_description'];
	}

	}
	
	# İşlemler Bitiş #
	
	
?>
ob_end_flush();