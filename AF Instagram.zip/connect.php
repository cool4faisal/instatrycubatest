<?php
include 'assets/inc/config.php';
$loginUrll = $instagram->getLoginUrl();
$e = mysql_fetch_assoc(mysql_query("select * from usluer_seo_settings where id='1'"));

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title><?php echo $e["title"];?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="<?php echo $e["description"];?>">
  <meta name="keywords" content="<?php echo $e["keywords"];?>">
<link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the browser URL, then refresh the page. -->
	
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet" type="text/css">

  <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  <![endif]-->

  <!-- Fav and touch icons -->
  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
  <link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  <link rel="shortcut icon" href="img/favicon.png">
  
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/scripts.js"></script>
	<script src="http://www.berkanyesilyurt.com/ajax-inline.js"></script>
</head>

<body bgcolor="#EEEEEC">
<br/>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="jumbotron">
				<h1>Instagram Auto Follow!</h1>
				<p>Kami tidak pernah menyimpan password member kami, karena kami memakai OAuth Instagram client.
				</p>

				<p>
					<a class="btn btn-primary btn-large" href="<? echo $loginUrll ?>">Masuk Dengan Akun Instagram</a>
					<a class="btn btn-primary btn-small" id="modal-660344" href="#modal-container-660344" role="button" data-toggle="modal" href="<? echo $loginUrll ?>">Tutorial Video ?</a>
				</p>
			</div>
		</div>
	</div>
</div>



<div class="modal fade" id="modal-container-660344" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							 <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
							<h4 class="modal-title" id="myModalLabel">
								Tutorial Video
							</h4>
						</div>
						<div class="modal-body">
							<iframe width="540" height="315" src="//www.youtube.com/embed/wc2dEmmxrpM" frameborder="0" allowfullscreen></iframe>
						</div>
						<div class="modal-footer">
							 <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
						</div>
					</div>
					
				</div>
				
</div>
</body>
</html>