-- MySQL dump 10.15  Distrib 10.0.25-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: fajabid1_demo
-- ------------------------------------------------------
-- Server version	10.0.25-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usluer_client`
--

DROP TABLE IF EXISTS `usluer_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usluer_client` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` varchar(225) NOT NULL,
  `client_secret` varchar(225) NOT NULL,
  `client_website` varchar(225) NOT NULL,
  `client_callback` varchar(225) NOT NULL,
  `client_name` varchar(225) NOT NULL,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `client_id` (`client_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usluer_client`
--

LOCK TABLES `usluer_client` WRITE;
/*!40000 ALTER TABLE `usluer_client` DISABLE KEYS */;
INSERT INTO `usluer_client` (`id`, `client_id`, `client_secret`, `client_website`, `client_callback`, `client_name`) VALUES (1,'0d44db72824746fdac3fbf620c21092a','15ad94bbd267469297ff428731bedac1','http://demo.tutorials.fajaralrahmansyah.web.id/creating%20webs/af-instagram/','http://demo.tutorials.fajaralrahmansyah.web.id/creating%20webs/af-instagram/callback.php','uygulamaismi');
/*!40000 ALTER TABLE `usluer_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usluer_genel_ayarlar`
--

DROP TABLE IF EXISTS `usluer_genel_ayarlar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usluer_genel_ayarlar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uyekredi` varchar(200) DEFAULT NULL,
  `ozeluyekredi` varchar(200) DEFAULT NULL,
  `paypalmailadresi` varchar(200) DEFAULT NULL,
  `ozeluyelikucreti` varchar(200) DEFAULT NULL,
  `giristetakip` varchar(200) DEFAULT NULL,
  `kullanici_id` varchar(200) DEFAULT NULL,
  `giristebegeni` varchar(200) DEFAULT NULL,
  `media_id` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usluer_genel_ayarlar`
--

LOCK TABLES `usluer_genel_ayarlar` WRITE;
/*!40000 ALTER TABLE `usluer_genel_ayarlar` DISABLE KEYS */;
INSERT INTO `usluer_genel_ayarlar` (`id`, `uyekredi`, `ozeluyekredi`, `paypalmailadresi`, `ozeluyelikucreti`, `giristetakip`, `kullanici_id`, `giristebegeni`, `media_id`) VALUES (1,'50','150','Farhananonim666@gmail.com','50','0','0','0','0');
/*!40000 ALTER TABLE `usluer_genel_ayarlar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usluer_iletisim`
--

DROP TABLE IF EXISTS `usluer_iletisim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usluer_iletisim` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `konu` varchar(255) NOT NULL,
  `mesaj` text NOT NULL,
  `ip_adresi` varchar(20) NOT NULL,
  `tarih` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usluer_iletisim`
--

LOCK TABLES `usluer_iletisim` WRITE;
/*!40000 ALTER TABLE `usluer_iletisim` DISABLE KEYS */;
/*!40000 ALTER TABLE `usluer_iletisim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usluer_instagram`
--

DROP TABLE IF EXISTS `usluer_instagram`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usluer_instagram` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(70) CHARACTER SET utf8 DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `bio` text CHARACTER SET utf8,
  `website` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `picture` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `durum` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `kredi` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `cinsiyet` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `sifre` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `instagram_id` int(11) DEFAULT NULL,
  `instagram_access_token` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `kredikazanmismi` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usluer_instagram`
--

LOCK TABLES `usluer_instagram` WRITE;
/*!40000 ALTER TABLE `usluer_instagram` DISABLE KEYS */;
INSERT INTO `usluer_instagram` (`id`, `username`, `name`, `bio`, `website`, `picture`, `durum`, `kredi`, `cinsiyet`, `sifre`, `instagram_id`, `instagram_access_token`, `kredikazanmismi`) VALUES (5,'mustafauzuncinar','Mustafa Uzunçınar','','','http://photos-f.ak.instagram.com/hphotos-ak-xpa1/1599278_565500156889429_9687016_a.jpg','0','50','0','0',1511477375,'1511477375.27c0d4c.af4330f1217e4e7794027a61262cc75d',0);
/*!40000 ALTER TABLE `usluer_instagram` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usluer_seo_settings`
--

DROP TABLE IF EXISTS `usluer_seo_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usluer_seo_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(225) NOT NULL,
  `keywords` varchar(225) NOT NULL,
  `description` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usluer_seo_settings`
--

LOCK TABLES `usluer_seo_settings` WRITE;
/*!40000 ALTER TABLE `usluer_seo_settings` DISABLE KEYS */;
INSERT INTO `usluer_seo_settings` (`id`, `title`, `keywords`, `description`) VALUES (1,'Instagram Followers','Auto Follows Instagram','Free Auto Follows Instagram');
/*!40000 ALTER TABLE `usluer_seo_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usluer_yonetim`
--

DROP TABLE IF EXISTS `usluer_yonetim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usluer_yonetim` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(70) DEFAULT NULL,
  `sifre` varchar(100) DEFAULT NULL,
  `isim` text,
  `kredi` varchar(200) DEFAULT NULL,
  `odenenmiktar` varchar(200) DEFAULT NULL,
  `durum` varchar(200) DEFAULT NULL,
  `telefon` varchar(200) DEFAULT NULL,
  `duyuru_durum` int(11) DEFAULT NULL,
  `duyuru` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usluer_yonetim`
--

LOCK TABLES `usluer_yonetim` WRITE;
/*!40000 ALTER TABLE `usluer_yonetim` DISABLE KEYS */;
INSERT INTO `usluer_yonetim` (`id`, `email`, `sifre`, `isim`, `kredi`, `odenenmiktar`, `durum`, `telefon`, `duyuru_durum`, `duyuru`) VALUES (1,'admin','admin','Admin','99999999','2500 TL','1','(555) 555 55 55',0,'Merhaba Berkan, ödemen onaylandı!');
/*!40000 ALTER TABLE `usluer_yonetim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'fajabid1_demo'
--

--
-- Dumping routines for database 'fajabid1_demo'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-08 20:38:55
