	$(function(){
		$("#btnSend").on("click", function(){
			$.ajax({
				type:"post",
				data:{instagram_id:$("#instagram_id").val()},
				url:"assets/inc/kredi.php",
				success:function(data) {
					$("#kredi").html(data);
				}
			});
		});
	});
	
	$(function(){
	$("#btnSend2").on("click", function(){
		$.ajax({
			type:"post",
			data: $('#iletisim').serialize(),
			url:"assets/inc/iletisim.php",
			success:function(data) {
				$("#gonderildi").html(data);
			}
		});
		return false;
		});
						
	});	
	
	$(function(){
	$("#btnSend3").on("click", function(){
		$.ajax({
			type:"post",
			data: $('#sifre').serialize(),
			url:"assets/inc/cinsiyet.php",
			success:function(data) {
				$("#kaydedildi").html(data);
			}
		});
		return false;
		});
						
	});	