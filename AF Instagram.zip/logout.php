<?php
@session_start();
session_destroy();
header('Location: ./connect.php');

// Bu dosyada düzenlenmesi gereken bir kısım yoktur.
// Dosyadaki oynamalar uzun vadede büyük açıklara sebep olabilir.
// Bu açıklamaları için Berkan Yeşilyurt'a bir teşekkür edebilirsiniz.
// Belki giren olur www.berkanyesilyurt.com
?>